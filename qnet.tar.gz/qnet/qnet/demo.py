import networkx as nx
import qnetwork_class as qnet
import numpy as np
from node_class import Node, GroundStation, Satelite
from edge_class import Edge
import matplotlib.pyplot as plt

if __name__ == "__main__":

    G = qnet.Qnetwork()
    
    GroundStation.set_node_properties(["country"])
    GroundStation.get_node_properties()
    
    
    Sydney = GroundStation("Sydney", "AU")
    Brisbane = GroundStation("Brisbane", "AU")
    Melbourne = GroundStation("Melbourne", "AU")
    Hobart = GroundStation("Hobart", "AU")
    WoyWoy = GroundStation("WoyWoy", "AU")
    Twinkle = Satelite("NXF2019", "AU")
    LittleStar = Satelite("NXF2021", "AU")

    G.add_nodes_from([Sydney, Brisbane, Melbourne, Hobart, WoyWoy, Twinkle])
    
    SydMel = Edge(Sydney, Melbourne, 1)
    print(SydMel.source)
    print(SydMel.dest)
    SydBri = Edge(Sydney, Brisbane, 2)
    e1 = Edge(Sydney, WoyWoy, 3)
    e2 = Edge(Sydney, Hobart, 1)
    e3 = Edge(Sydney, Twinkle, 4)
    e4 = Edge(Melbourne, Hobart, 1)
    e5 = Edge(Melbourne, Twinkle, 3)
    e6 = Edge(Brisbane, Twinkle, 1)
    e7 = Edge(Hobart, Twinkle, 4)
    
    G.add_edge(SydMel)
    G.add_edge(SydBri)
    
    
    G.add_edges_from([e1, e2, e3, e4, e5, e6, e7])

    nx.draw(G, with_labels=True, font_weight='bold')
    plt.show()
