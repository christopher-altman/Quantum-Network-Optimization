name = "qnet"

import os

from .node_class import Node, GroundStation, Satelite
from .edge_class import Edge, FreeSpace, Fiber
from .qnetwork_class import qnetwork


def info():
    print('QNET (February 2019) - by Maria Kieferova & Peter Rohde')