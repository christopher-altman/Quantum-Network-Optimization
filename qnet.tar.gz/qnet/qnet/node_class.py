
class Node(object):
    """This is a base class for nodes in a quantum network
    
    
        Parameters
        ----------
        
        name: identifier for the node, required
        
        incoming_properties : optional for the class, required for each member of the class
        
        **kwargs: optional keyword arguments, defult=None
        
        
        Examples
        -----------
        
        specify the properties of all nodes
        
        >> Node.set_node_properties(["country"])
        
        this can be done only once before creating any nodes
        
        the properties of the nodes can be recalled as
        
        GroundStation.get_node_properties()
        
        create a node
        
        >>>Sydney = Node("Sydney", country = "AU")
        
        the name of the node is Sydney
        
        Subclasses
        -----------
        GroundStation, Satelite
        
        
    """
    
    _properties = []#todo: come up with a better way to store these
    
    
    #run this before making any objects!!!!
    @classmethod
    def set_node_properties(cls, arr):
        print(cls._properties)
        if cls._properties == []:
            cls._properties = arr
        else :
            print("Nodes in this network already have a set of properties")
        print(cls._properties)
        
    @classmethod
    def get_node_properties(cls):
        print(cls._properties)    
    
    
    def __init__(self, name, *properties, **kwargs):
        """ Constructor for a node
        
        """
    
        self.name = name
        for key in properties:
            self.__dict__[key] = key
            

    def __str__(self):
        """ The identifier of the node is in the variable "name"
        """
        return(str(self.name))
    

class GroundStation(Node):
    """
    Class for creating immobile nodes on the Earth
    
    Inherits from Node
    
    Properties
    ----------
    
    Examples
    --------
    """
        
    def __init__(self, *args):
        super().__init__(  *args)
        


class Satelite(Node):
    """
    Class for creating satelite nodes
    
    Inherits from Node
    
    Properties
    ----------
    
    Examples
    --------
    """
    
    def __init__(self, *args):
        super().__init__( *args)
        
