import networkx as nx
from edge_class import Edge
from node_class import Node


class Qnetwork(nx.Graph):
    
    def __init__(self, *args, **kwargs):
        super().__init__(  *args, **kwargs)
        
    
    def add_edge(self, my_edge):
        super().add_edge(my_edge.source, my_edge.dest, edge = my_edge)
        
    def add_edges_from(self, ebunch_to_add):
        for my_edge in ebunch_to_add:
            self.add_edge(my_edge)