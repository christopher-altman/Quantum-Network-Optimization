import networkx as nx

class Edge(object):
    #dictionary of atributes
    properties = ['weight']

    def __init__(self, source, dest,   *properties):
        self.source = source
        self.dest = dest
        self.name = str(source)+"->"+str(dest)
        for key in properties:
            self.__dict__[key] = key

    def __str__(self):
        return('Edge: ' + self.name)
    
    #I'm lost!!!
    #@classmethod
    #def add_edge(cls, source, dest,  *properties):
        #return(Edge(source, dest,  *properties))


class FreeSpace(Edge):
    
    damping_const = 10e-5
    
    def losses(distance, const):
        pass
    
    def __init__(self, distance,  *args, **kwargs):
        self.distance = distance
        self.noise_rate = losses(distance, damping_const)
        super().__init__(  *args)
    

        

        
        
class Fiber(Edge):
    damping_const = 10e-3
    
    def losses(distance, const):
        pass
    
    def __init__(self, distance,  *args, **kwargs):
        self.distance = distance
        self.noise_rate = losses(distance, damping_const)
        super().__init__(  *args)

    



        
    